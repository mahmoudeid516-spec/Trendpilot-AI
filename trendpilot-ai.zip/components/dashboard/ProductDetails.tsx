type Product = {
  image: string;
  name: string;
  platform: string;
  ai_score: number;
  trend_score: number;
  profit: number;
  buy_price: number;
  selling_price: number;
  supplier: string;
  supplier_url: string;
  product_url: string;
  competition: string;
  country: string;
  category: string;
  description?: string;
  ai_reason?: string;
};

type ProductDetailsProps = {
  product: Product;
};

export default function ProductDetails({
  product,
}: ProductDetailsProps) {
  return (
    <div className="bg-white rounded-3xl shadow-xl p-8 mt-10">

      <div className="grid lg:grid-cols-2 gap-10">

        {/* Product Image */}
        <div>
          <img
            src={product.image}
            alt={product.name}
            className="w-full rounded-3xl object-cover"
          />
        </div>

        {/* Product Info */}
        <div>

          <h1 className="text-4xl font-bold">
            {product.name}
          </h1>

          <p className="text-gray-500 mt-3">
            {product.description || "AI analyzed this product and found high selling potential."}
          </p>

          <div className="grid grid-cols-2 gap-4 mt-8">

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">AI Score</p>
              <h2 className="text-3xl font-bold text-green-600">
                {product.ai_score}
              </h2>
            </div>

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">Trend Score</p>
              <h2 className="text-3xl font-bold text-purple-600">
                {product.trend_score}
              </h2>
            </div>

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">Buy Price</p>
              <h2 className="text-2xl font-bold">
                ${product.buy_price}
              </h2>
            </div>

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">Selling Price</p>
              <h2 className="text-2xl font-bold">
                ${product.selling_price}
              </h2>
            </div>

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">Expected Profit</p>
              <h2 className="text-2xl font-bold text-green-600">
                ${product.profit}
              </h2>
            </div>

            <div className="bg-gray-100 rounded-xl p-4">
              <p className="text-gray-500">Competition</p>
              <h2 className="text-2xl font-bold">
                {product.competition || "Medium"}
              </h2>
            </div>

          </div>

          <div className="mt-8 bg-purple-50 rounded-2xl p-6">

            <h3 className="text-xl font-bold mb-3">
              🤖 AI Recommendation
            </h3>

            <p className="text-gray-700">
              {product.ai_reason ||
                "This product has a strong profit margin, increasing demand, and good viral potential."}
            </p>

          </div>

          <div className="mt-8 grid grid-cols-2 gap-4">

            <a
              href={product.product_url || "#"}
              target="_blank"
              className="bg-gray-900 text-white text-center py-4 rounded-xl hover:bg-black transition"
            >
              View Supplier
            </a>

            <button
              className="bg-purple-600 hover:bg-purple-700 text-white py-4 rounded-xl transition"
            >
              🚀 Launch Product
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}