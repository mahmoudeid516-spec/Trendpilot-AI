import { NextResponse } from "next/server";
import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY!,
});

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const prompt = body.product;

    const response = await openai.responses.create({
      model: "gpt-4.1-mini",
      input: `
Analyze this product:

${prompt}

Return ONLY a valid JSON object.

{
  "name":"",
  "category":"",
  "description":"",
  "buy_price":0,
  "selling_price":0,
  "profit":0,
  "ai_score":0,
  "trend_score":0
}
`,
    });

    const text = response.output_text ?? "";

    const start = text.indexOf("{");
    const end = text.lastIndexOf("}");

    if (start === -1 || end === -1) {
      throw new Error("No JSON found.");
    }

    const json = text.slice(start, end + 1);
    const result = JSON.parse(json);

    return NextResponse.json({
      result,
    });
  } catch (err) {
    console.error(err);

    return NextResponse.json(
      {
        error: String(err),
      },
      {
        status: 500,
      }
    );
  }
}